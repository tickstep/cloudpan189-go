# 关于
RPM打包cloudpan189-go

# 如何打包
系统需要安装先rpmbuild
```
yum install rpm-build -y 
```

需要打包的二进制文件目标目录层次存放到BUILDROOT目录下面，spec文件存放在SPECS目录里面，然后使用rpmbuild命令进行打包
```
rpmbuild -bb SPECS/cloudpan189-go-linux-x64.spec
```

打包好的文件会存放到RPMS目录下面。

# 安装
打包好的文件存放到RPMS目录下面，cd到该目录进行安装
```
rpm -ivh cloudpan189-go-0.0.9-1.x86_64.rpm
```

# 卸载
```
rpm -e --nodeps cloudpan189-go-0.0.9-1
```

# 其他
提取rpm文件中的spec文件，然后保存即可
```
rpmrebuild -e -p --notest-install <rpm文件>

e.g.
rpmrebuild -e -p --notest-install cloudpan189-go-0.0.9-1.x86_64.rpm
```

解压rpm文件中包含的文件到当前目录
```
rpm2cpio <rpm文件> | cpio -div

e.g.
rpm2cpio cloudpan189-go-0.0.9-1.x86_64.rpm | cpio -div
```




